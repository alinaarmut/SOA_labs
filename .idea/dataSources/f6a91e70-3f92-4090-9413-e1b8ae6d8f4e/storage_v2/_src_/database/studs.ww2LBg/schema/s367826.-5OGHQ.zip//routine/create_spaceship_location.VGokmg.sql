create function create_spaceship_location() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO location (spaceship_id)
  VALUES (NEW.id);
  RETURN NEW;
END;
$$;

alter function create_spaceship_location() owner to s367826;

