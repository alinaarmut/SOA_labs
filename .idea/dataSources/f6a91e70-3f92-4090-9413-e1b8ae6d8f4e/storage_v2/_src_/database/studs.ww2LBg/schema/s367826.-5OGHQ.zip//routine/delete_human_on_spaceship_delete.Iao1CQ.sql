create function delete_human_on_spaceship_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM human
    WHERE spaceship_id = OLD.id;
    
    RETURN OLD;
END;
$$;

alter function delete_human_on_spaceship_delete() owner to s367826;

