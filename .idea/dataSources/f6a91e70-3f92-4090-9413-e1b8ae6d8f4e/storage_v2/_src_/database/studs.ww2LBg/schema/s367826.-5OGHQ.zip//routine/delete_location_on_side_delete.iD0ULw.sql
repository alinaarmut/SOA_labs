create function delete_location_on_side_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM location
    WHERE right_id_side = OLD.id OR left_id_side = OLD.id;
    RETURN OLD;
END;
$$;

alter function delete_location_on_side_delete() owner to s367826;

