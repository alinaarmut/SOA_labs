create function update_crew_data() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.spaceship_id IS NOT NULL THEN
    UPDATE location
    SET current_location = NEW.spaceship_id
    WHERE spaceship_id = NEW.spaceship_id;
  END IF;
  RETURN NEW;
END;
$$;

alter function update_crew_data() owner to s367826;

