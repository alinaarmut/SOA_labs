create function update_location_info() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO location (spaceship_id, name_spaceship)
  VALUES (NEW.spaceship_id, NEW.name_spaceship);
  RETURN NEW;
END;
$$;

alter function update_location_info() owner to s367826;

