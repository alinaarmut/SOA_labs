create function update_spaceship_location() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    -- Обновление записи в таблице spaceship_location
    UPDATE spaceship_location
    SET current_location = NEW.current_location
    WHERE spaceship_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;

alter function update_spaceship_location() owner to s367826;

