create procedure update_subscription_status()
    language plpgsql
as
$$
begin
   update subscription
   set subscription_status = 'inactive'
   where end_date < current_date
     and subscription_status != 'inactive';
end;
$$;

alter procedure update_subscription_status() owner to s367826;

