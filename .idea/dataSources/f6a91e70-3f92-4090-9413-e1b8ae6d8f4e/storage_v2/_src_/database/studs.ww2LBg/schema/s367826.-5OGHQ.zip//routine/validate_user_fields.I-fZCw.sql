create function validate_user_fields() returns trigger
    language plpgsql
as
$$
BEGIN

    IF EXISTS (SELECT 1 FROM "user_app_formulas" WHERE email = NEW.email) THEN
        RAISE EXCEPTION 'Почта уже существует';
    END IF;

    IF EXISTS (SELECT 1 FROM "user_app_formulas" WHERE username = NEW.username) THEN
        RAISE EXCEPTION 'Логин уже существует';
    END IF;

    IF LENGTH(NEW.password) < 8 THEN
        RAISE EXCEPTION 'Пароль должен быть не менее 8 символов';
    END IF;

    RETURN NEW;
END;
$$;

alter function validate_user_fields() owner to s367826;

